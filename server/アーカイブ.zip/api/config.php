<?php
// 診断村 いいね集計用 DB接続情報。
// このファイルは絶対に公開リポジトリに含めないこと(.gitignoreで除外済み)。
return [
    'host' => 'localhost',
    'dbname' => 'xs896598_shindanmura',
    'user' => 'xs896598_katsuya',
    'password' => 'katuya7533',
    'charset' => 'utf8mb4',
];
